#!/bin/bash

#SBATCH --job-name=armadillo
#SBATCH --time=01:05:00
#SBATCH --account=nn2849k
#SBATCH --mem-per-cpu=3850M
###SBATCH --output=Output_File.out
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16

export OMP_NUM_THREADS=1


 ./app 1e4

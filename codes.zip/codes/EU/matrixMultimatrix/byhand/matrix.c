//compute C=alpha*A*B+beta*C, A,B,C are matrices with size N*N

#include<stdio.h>
#include<time.h>
#include<omp.h>
#include<immintrin.h>
#define   A(x,y)    A[(x)*(N)+(y)]
#define   B(x,y)    B[(x)+(y)*(N)]


#define   C(x,y)    C[(x)*(N)+(y)]

int looptimes=10;

int main( int nargs, char** args )
{
	int i,j,k;
	int N=1e4;

	if (nargs>1)
		N = atof(args[1]);




	double sum=0.0;
	double *A,*B,*C;
	double start, finish;
	double alpha=2.1;
	double beta=1.2; 


	A=(double*)_mm_malloc(N*N*sizeof(double),64);
	B=(double*)_mm_malloc(N*N*sizeof(double),64);
	C=(double*)_mm_malloc(N*N*sizeof(double),64);





#pragma omp parallel for default(shared) private(i,j)
	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
		{
			A(i,j)=1.0*(i+j)/N;
			B(i,j)=1.0*(i*j)/N;
			C(i,j)=1.0*(j*j)/N;
		}


	start=omp_get_wtime();
	int p;

	for(p=0;p<looptimes;p++)
	{
#pragma omp parallel for default(shared) private(i,j,k,sum)
		for(i=0;i<N;i++)
			for(j=0;j<N;j++)
			{   
				sum=0.0;
				for(k=0;k<N;k++)
				{
					sum+= A(i,k)*B(k,j);   
				}
				C(i,j)=alpha*sum+beta*C(i,j);
			}

	}

	finish=omp_get_wtime();

	printf("C(5,5) %e\n",C(5,5));




#pragma omp parallel
	{
#pragma omp master
		printf("N= %d, number of threads=%d,  time usage is %e\n",N, omp_get_num_threads( ) , (finish-start)/looptimes);
	}
	_mm_free(A);
	_mm_free(B);
	_mm_free(C);

	return 0;

}


#!/bin/bash

#SBATCH --job-name=armadillo
#SBATCH --time=01:05:00
#SBATCH --account=nn2849k
#SBATCH --mem-per-cpu=3850M
###SBATCH --output=Output_File.out
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16

export OMP_NUM_THREADS=8


#numactl --physcpubind=0,2,4,8  ./app 10000
numactl --physcpubind=0,1,2,3,4,5,6,7  ./app 10000

#include <stdio.h>
#include <stdlib.h>
#include "mkl.h"
#include<time.h>
#define   A(x,y)    A[(x)*N+(y)]
#define   B(x,y)    B[(x)*N+(y)]
#define   C(x,y)    C[(x)*N+(y)]

int looptimes=10;
int main(int nargs, char** args)
{   

	int  N=10000;
	if (nargs>1)
		N = atof(args[1]);


	double *A, *B, *C;
	long  m, n, k, i, j;
	double alpha, beta;
	//    m = 10000, k = 10000, n = 10000;
	m = N, k = N, n = N;
	//  m = 50, k = 50, n = 50;
	alpha = 1.3; beta = 3.1;

	printf (" Allocating memory for matrices aligned on 64-byte boundary for better \n"
			" performance \n\n");
	A = (double *)mkl_malloc( N*N*sizeof( double ), 64 );
	B = (double *)mkl_malloc( N*N*sizeof( double ), 64 );
	C = (double *)mkl_malloc( N*N*sizeof( double ), 64 );
	if (A == NULL || B == NULL || C == NULL) {
		printf( "\n ERROR: Can't allocate memory for matrices. Aborting... \n\n");
		mkl_free(A);
		mkl_free(B);
		mkl_free(C);
		return 1;
	}

	int t;

#pragma omp parallel for default(shared) private(i,j)
	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
		{
			A(i,j)=1.0*(i+j)/N;
			B(i,j)=1.0*(i*j)/N;
		}
	double start = dsecnd();

	int counter=0;
	for(t=0;t<looptimes;t++)
	{
		counter++;
#pragma omp parallel for default(shared) private(i,j)    
		for(i=0;i<N;i++)
			for(j=0;j<N;j++)
			{
				C(i,j)=alpha*A(i,j)+beta*B(i,j);
			}


	}
	double finish = dsecnd();
#pragma omp parallel
	{
#pragma omp master
		printf("N= %ld, number of threads=%d, average time usage is %e\n",N, omp_get_num_threads( ) , (finish-start)/looptimes );
	}

	printf("counter %d\n",counter);

	printf("C(%ld,%ld) is %e\n.",N-2,N-2,C(N-2,N-2)) ;           

	mkl_free(A);
	mkl_free(B);
	mkl_free(C);

	//	printf (" Example completed. \n\n");
	return 0;
}

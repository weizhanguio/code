#include <iostream>
//#define ARMA_64BIT_WORD
#include "armadillo"
#include<time.h>
#include<omp.h>


using namespace arma;
using namespace std;

int looptimes=10;


int main(int nargs, char** args)
{
	// cout << "Armadillo version: " << arma_version::as_string() << endl;

	long N=1e4;

	if (nargs>1)
		N = atof(args[1]);


	mat A(N,N);
	mat B(N,N);
	mat C(N,N);

        double  start,finish;
        double alpha=1.3;       
        double beta=3.1;       

	int i,j,t;


#pragma omp parallel for
	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
		{
			A(i,j)=1.0*(i+j)/N;
			B(i,j)=1.0*(i*j)/N;
		}
	start=omp_get_wtime();  

	for(t=0;t<looptimes;t++)
	{


		C=alpha*A+beta*B;
	}
	finish=omp_get_wtime();

#pragma omp parallel
	{
#pragma omp master
		printf("N= %ld, number of threads=%d, average time usage is %e\n",N, omp_get_num_threads( ) , (finish-start)/looptimes);
	}

	printf("C(%ld,%ld) is %e\n.",N-2,N-2,C(N-2,N-2)) ;

	return 0;
}


#include<mkl.h>
#include<stdio.h>
#include<stdlib.h>
#include<omp.h>

int looptimes=1;
int main( int nargs, char** args)
{

	double one = 1.0;
	int t;

	 MKL_INT  N=50;
	if (nargs>1)
		N = atof(args[1]);


	MKL_INT i;



	double* values=(double *)mkl_malloc((3*N-2)*sizeof(double),64);
	MKL_INT* rows=(MKL_INT *)mkl_malloc((3*N-2)*sizeof(MKL_INT),64);
	MKL_INT* pointerB=(MKL_INT *)mkl_malloc(N*sizeof(MKL_INT),64);
	MKL_INT* pointerE=(MKL_INT *)mkl_malloc(N*sizeof(MKL_INT),64);

	double  *b=(double *)mkl_malloc(N*sizeof(double),64);
	double  *c=(double *)mkl_malloc(N*sizeof(double),64);



	#pragma omp parallel for
	for(i=0;i<3*N-2;i++)
		values[i]=-1.0;


        #pragma omp parallel for
        for(i=0;i<N;i++)
                values[3*i]=2.0;





	rows[0]=0;
	rows[1]=1;
	rows[3*N-4]=N-2;
	rows[3*N-3]=N-1;

	#pragma omp parallel for
	for(i=1;i<=N-2;i++)
	{
		rows[3*i-1]=i-1;
		rows[3*i]=i;
		rows[3*i+1]=i+1;

	}

	#pragma omp parallel for
	for(i=0;i<=N-1;i++)
	{
		b[i]=1.0;
		c[i]=0.0;
	}  


	#pragma omp parallel for
	for(i=1;i<=N-1;i++)
		pointerB[i]=i*3-1;

	pointerB[0]=0;

	#pragma omp parallel for
	for(i=1;i<=N-2;i++)
		pointerE[i]= pointerB[i]+3;

	pointerE[0]=pointerB[0]+2;
	pointerE[N-1]=pointerB[N-1]+2;



	double alpha=1.0;
	double beta=1.0;
	double start= dsecnd();

	// y = alpha*A*x + beta*y
	for(t=0;t<looptimes;t++)
	{
		//mkl_dcscmv("N", &N, &N, &one, "G**C", values, rows, pointerB, pointerE, b, &one, c);
		mkl_dcscmv("N", &N, &N, &alpha, "G**C", values, rows, pointerB, pointerE, b, &beta, c);
	}

	double finish= dsecnd();








#pragma omp parallel
	{
#pragma omp master
		printf("N= %ld, number of threads=%d,  time usage is %e\n\n\n",N, omp_get_num_threads( ) , (finish-start)/looptimes);
	}


	mkl_free(values);
	mkl_free(rows);
	mkl_free(pointerB);
	mkl_free(pointerE);
	mkl_free(b);
	mkl_free(c);

	return 0;

}

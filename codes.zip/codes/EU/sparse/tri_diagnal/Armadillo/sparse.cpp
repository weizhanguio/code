#include <iostream>
#define ARMA_64BIT_WORD
#include "armadillo"
#include<time.h>
#include<omp.h>
int looptimes=1;

using namespace arma;
using namespace std;

int main(int nargs, char** args)
{
	//  cout << "Armadillo version: " << arma_version::as_string() << endl;
	long N=1e6;
	if (nargs>1)
		N = atof(args[1]);

	//double  start,finish;
	wall_clock timer;
	int t;


	umat locations(2,3*N-2);

	double alpha=1.0;
	double beta=1.0;


	long i,j;
#pragma omp parallel  for
	for(i=1;i<=N-2;i++)
	{
		locations(0,i*3-1)=i-1;
		locations(1,i*3-1)=i;

		locations(0,i*3)=i;
		locations(1,i*3)=i;

		locations(0,i*3+1)=i+1;
		locations(1,i*3+1)=i;
	}


	locations(0,0)=0;
	locations(1,0)=0;
	locations(0,1)=1;
	locations(1,1)=0;

	locations(0,3*N-4)=N-2;
	locations(1,3*N-4)=N-1;
	locations(0,3*N-3)=N-1;
	locations(1,3*N-3)=N-1;




	vec values(3*N-2);
#pragma omp parallel for
	for(i=0;i<3*N-2;i++)
		values(i)=-1.0;

#pragma omp parallel for
	for(i=0;i<N;i++)
		values[3*i]=2.0;


	sp_mat A(locations, values, true);

	vec b(N);
	vec c(N);
#pragma omp parallel for
	for(i=0;i<N;i++)
	{
		b(i)=1.0;
		c(i)=0.0;
	}


	timer.tic();

	for(t=0;t<looptimes;t++)
	{
		c=alpha*A*b+beta*c;
	}

	double n_secs = timer.toc();





#pragma omp parallel
	{
#pragma omp master
		printf("N= %ld, number of threads=%d,  time usage is %e\n\n\n",N, omp_get_num_threads( ) , n_secs/looptimes);
	}


	return 0;
}


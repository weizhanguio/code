// *************************************************************************
//
//    PARALUTION   www.paralution.com
//
//    Copyright (C) 2012-2014 Dimitar Lukarski
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
// *************************************************************************



// PARALUTION version 0.7.0 


#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <omp.h>

#include <paralution.hpp>

using namespace paralution;

int main(int argc, char* argv[]) {

	if (argc == 1) { 
		std::cerr << argv[0] << " <matrix> [Num threads]" << std::endl;
		exit(1);
	}


	init_paralution();




	info_paralution();

	LocalVector<double> x;
	LocalVector<double> rhs;
	LocalVector<double> c;

	LocalMatrix<double> mat;
	//  mat.ReadFileMTX(std::string(argv[1]));

	//int *row=new int[7];
	//
	mat.MoveToAccelerator();
	x.MoveToAccelerator();
	rhs.MoveToAccelerator();
	c.MoveToAccelerator();




	long i;  


	int nx,ny,nz;
	nx=4;

	if (argc > 2) {
		set_omp_threads_paralution(atoi(argv[1]));
		nx=atoi(argv[2]);
	} 

	ny=nx;
	nz=nx;


	int ix,iy,iz;
	long N1,N2,nnz; 
	long s; 
	N1=3*nx-2;
	N2=N1*nx+nx*2*(nx-1);
	nnz=N2*nx+2*(nx-1)*nx*nx;  
	int *row=(int*)malloc(nnz*sizeof(int));
	int *col=(int*)malloc(nnz*sizeof(int));
	double *A=(double*)malloc(nnz*sizeof(double));
	long counter=0;

	for(i=0;i<nx*ny*nz;i++)
	{
		iz=i%nz;
		iy=((i-iz)/nz)%ny;
		ix=(i-iz-ny*iy)/(ny*nz);
		//printf("%d, %d, %d\n",ix,iy,iz);


		//           back=ix-1;
		if((ix-1)>=0)
		{
			s= (ix-1)*ny*nz+iy*nz+iz;  
			row[counter]=i;
			col[counter]=s;
			counter++;


		}

		//         left=iy-1;
		if((iy-1)>=0)
		{
			s=  ix*ny*nz+(iy-1)*nz+iz; 
			row[counter]=i;
			col[counter]=s;
			counter++;
		}


		//	down=iz-1; 
		if((iz-1)>=0)
		{
			s=  ix*ny*nz+iy*nz+iz-1; 
			row[counter]=i;
			col[counter]=s;
			counter++;
		}



		s= ix*ny*nz+iy*nz+iz; 
		row[counter]=i;
		col[counter]=s;
		counter++;
		//      up=iz+1;

		if((iz+1)<=(nz-1))
		{
			s=ix*ny*nz+iy*nz+iz+1;
			row[counter]=i;
			col[counter]=s;
			counter++;
		}

		//	right=iy+1;
		if((iy+1)<=(ny-1))
		{
			s=ix*ny*nz+(iy+1)*nz+iz;
			row[counter]=i;
			col[counter]=s;
			counter++;
		}
		//	front=ix+1;
		if((ix+1)<=(nx-1))
		{
			s= (ix+1)*ny*nz+iy*nz+iz;
			row[counter]=i;
			col[counter]=s;
			counter++;


		}



	}




	for(i=0;i<nnz;i++)
	{
		if(row[i]==col[i])
			A[i]=6.0;
		else
			A[i]=-1.0; 
	}








	//	long N=1e8;

	double *value=(double *)malloc((nnz)*sizeof(double));

	int *row_1=(int *)malloc(nnz*sizeof(int));
	int *col_1=(int *)malloc(nnz*sizeof(int));
	//	int *col;

#pragma omp parallel for
	for(i=0;i<nnz;i++)
		value[i]=A[i];




#pragma omp parallel for
	for(i=0;i<nnz;i++)
	{
		row_1[i]=row[i];
		col_1[i]=col[i];


	}



	mat.SetDataPtrCOO(&row_1,&col_1,&value,"matrix",nnz,nx*nx*nx,nx*nx*nx);

	mat.ConvertToCSR();

	x.Allocate("x",mat.get_nrow());
	rhs.Allocate("rhs",mat.get_nrow());
	c.Allocate("c",mat.get_nrow());
#pragma omp parallel for
	for(i=0;i<nx*nx*nx;i++)
	{
		x[i]=1.0;
		c[i]=1.0*i*i;

	}

	double alpha=1.8;
	double beta=2.1;

	double tick,tack;
	tick=paralution_time();

	mat.Apply(x,&rhs);
#pragma omp parallel for
	for(i=0;i<nx*nx*nx;i++)
	{
		c[i]=alpha*rhs[i]+beta*c[i];

	}



	tack=paralution_time();

	std::cout<<"N="<<nx*nx*nx<<", time:"<<(tack-tick)/1e6<<std::endl;


	free(row);
	free(col);
	free(row_1);
	free(col_1);
	free(A);
	free(value);
	stop_paralution();

	return 0;
}

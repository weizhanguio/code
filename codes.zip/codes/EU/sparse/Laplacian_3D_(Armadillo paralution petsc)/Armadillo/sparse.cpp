#include <iostream>
#define ARMA_64BIT_WORD
#include "armadillo"
#include<time.h>
#include<omp.h>
int looptimes=1;

using namespace arma;
using namespace std;

 

int main(int nargs, char** args)
{
	



	wall_clock timer;
	int t;



	double alpha=1.0;
	double beta=1.0;


	long i,j;
	
	
	
	int nx,ny,nz;
	nx=4;
	
	if (nargs>1)
		nx = atof(args[1]);
	
	ny=nx;
	nz=nx;


	int ix,iy,iz;
	long N1,N2,nnz; 
	long s; 
	N1=3*nx-2;
	N2=N1*nx+nx*2*(nx-1);
	nnz=N2*nx+2*(nx-1)*nx*nx;  
	int *row=(int*)malloc(nnz*sizeof(int));
	int *col=(int*)malloc(nnz*sizeof(int));
	double *A=(double*)malloc(nnz*sizeof(double));
	long counter=0;

	for(i=0;i<nx*ny*nz;i++)
	{
		iz=i%nz;
		iy=((i-iz)/nz)%ny;
		ix=(i-iz-ny*iy)/(ny*nz);
		//printf("%d, %d, %d\n",ix,iy,iz);


		//           back=ix-1;
		if((ix-1)>=0)
		{
			s= (ix-1)*ny*nz+iy*nz+iz;  
			row[counter]=i;
			col[counter]=s;
			counter++;


		}

		//         left=iy-1;
		if((iy-1)>=0)
		{
			s=  ix*ny*nz+(iy-1)*nz+iz; 
			row[counter]=i;
			col[counter]=s;
			counter++;
		}


		//	down=iz-1; 
		if((iz-1)>=0)
		{
			s=  ix*ny*nz+iy*nz+iz-1; 
			row[counter]=i;
			col[counter]=s;
			counter++;
		}



		s= ix*ny*nz+iy*nz+iz; 
		row[counter]=i;
		col[counter]=s;
		counter++;
		//      up=iz+1;

		if((iz+1)<=(nz-1))
		{
			s=ix*ny*nz+iy*nz+iz+1;
			row[counter]=i;
			col[counter]=s;
			counter++;
		}

		//	right=iy+1;
		if((iy+1)<=(ny-1))
		{
			s=ix*ny*nz+(iy+1)*nz+iz;
			row[counter]=i;
			col[counter]=s;
			counter++;
		}
		//	front=ix+1;
		if((ix+1)<=(nx-1))
		{
			s= (ix+1)*ny*nz+iy*nz+iz;
			row[counter]=i;
			col[counter]=s;
			counter++;


		}



	}



       
        for(i=0;i<nnz;i++)
     {
          if(row[i]==col[i])
           A[i]=6.0;
           else
           A[i]=-1.0; 
     }


	
	
	
	
	
	
	
	umat locations(2,nnz);
	
	

	
	
#pragma omp parallel  for
	for(i=0;i<nnz;i++)
	{
		locations(0,i)=row[i];
		locations(1,i)=col[i];

	
	}




	vec values(nnz);
#pragma omp parallel for
	for(i=0;i<nnz;i++)
		values(i)=A[i];



	sp_mat A1(locations, values, true);

	vec b(nx*nx*nx);
	vec c(nx*nx*nx);
#pragma omp parallel for
	for(i=0;i<nx*nx*nx;i++)
	{
		b(i)=1.0;
		c(i)=0.0;
	}


	timer.tic();

	for(t=0;t<looptimes;t++)
	{
		c=alpha*A1*b+beta*c;
	}

	double n_secs = timer.toc();
	cout<<A1<<endl;

  cout<<c<<endl;
  


#pragma omp parallel
	{
#pragma omp master
		printf("N= %ld, number of threads=%d,  time usage is %e\n\n\n",nx*nx*nx, omp_get_num_threads( ) , n_secs/looptimes);
	}


	free(row);
	free(col);
	free(A);


	return 0;
}


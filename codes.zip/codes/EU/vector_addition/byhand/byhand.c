#include <stdio.h>
#include <stdlib.h>
#include "mkl.h"
#include<time.h>
int main(int nargs, char** args)
{   

	long  N=1e8;

	if (nargs>1)
		N = atof(args[1]);

	double *A, *B;
	long  m, n, k, i, j;
	double alpha, beta;

	alpha = 1.0; beta = 1.0;
	int looptimes=10; 
	A = (double *)mkl_malloc( N*sizeof( double ), 64 );
	B = (double *)mkl_malloc( N*sizeof( double ), 64 );
	if (A == NULL || B == NULL) {
		printf( "\n ERROR: Can't allocate memory for matrices. Aborting... \n\n");
		mkl_free(A);
		mkl_free(B);
		return 1;
	}



#pragma omp parallel for
		for(i=0;i<N;i++)
		{
			A[i]=1.0*(i+i)/N;
			B[i]=1.0*(i*i)/N;
            }
      double start = dsecnd();

        for(j=0;j<looptimes;j++)
        {
#pragma omp parallel for                
            for(i=0;i<N;i++)
                {
            //            B[i]=alpha*A[i]+beta*B[i];
                        B[i]=A[i]+B[i];
            }


	}
	double finish = dsecnd();


#pragma omp parallel
	{
#pragma omp master
		printf("N= %ld, number of threads=%d, average time usage is %e\n",N, omp_get_num_threads( ) , (finish-start)/looptimes );
	}


	printf ("B[%d]: %e\n",N-1,B[N-1]);
	mkl_free(A);
	mkl_free(B);

	return 0;
}

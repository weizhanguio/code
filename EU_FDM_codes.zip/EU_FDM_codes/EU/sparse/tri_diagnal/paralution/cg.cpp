// *************************************************************************
//
//    PARALUTION   www.paralution.com
//
//    Copyright (C) 2012-2014 Dimitar Lukarski
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
// *************************************************************************



// PARALUTION version 0.7.0 


#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <omp.h>

#include <paralution.hpp>

using namespace paralution;

int main(int argc, char* argv[]) {

	if (argc == 1) { 
		std::cerr << argv[0] << " <matrix> [Num threads]" << std::endl;
		exit(1);
	}


	init_paralution();

	long N=50;

	if (argc > 2) {
		set_omp_threads_paralution(atoi(argv[1]));
		N=atoi(argv[2]);
	} 

	info_paralution();

	LocalVector<double> x;
	LocalVector<double> rhs;
	LocalVector<double> c;

	LocalMatrix<double> mat;
	//  mat.ReadFileMTX(std::string(argv[1]));

	//int *row=new int[7];
	//
	mat.MoveToAccelerator();
	x.MoveToAccelerator();
	rhs.MoveToAccelerator();
	c.MoveToAccelerator();

	//	long N=1e8;
	long i;  
	double *value=(double *)malloc((3*N-2)*sizeof(double));

	int *row=(int *)malloc((3*N-2)*sizeof(int));
	int *col=(int *)malloc((3*N-2)*sizeof(int));
	//	int *col;

#pragma omp parallel for
	for(i=0;i<3*N-2;i++)
		value[i]=-1.0;

#pragma omp parallel for
	for(i=0;i<N;i++)
		value[3*i]=2.0;

	row[0]=0;
	col[0]=0;
	row[1]=0;
	col[1]=1;
	row[3*N-4]=N-1;
	col[3*N-4]=N-2;
	row[3*N-3]=N-1;
	col[3*N-3]=N-1;

#pragma omp parallel for
	for(i=1;i<=N-2;i++)
	{
		row[3*i-1]=i;
		col[3*i-1]=i-1;
		row[3*i]=i;
		col[3*i]=i;
		row[3*i+1]=i;
		col[3*i+1]=i+1;

	}



	mat.SetDataPtrCOO(&row,&col,&value,"matrix",3*N-2,N,N);

	mat.ConvertToCSR();

	x.Allocate("x",mat.get_nrow());
	rhs.Allocate("rhs",mat.get_nrow());
	c.Allocate("c",mat.get_nrow());
#pragma omp parallel for
	for(i=0;i<=N-1;i++)
	{
		x[i]=1.0;
		c[i]=1.0*i*i/N;

	}

	double alpha=1.8;
	double beta=2.1;

	double tick,tack;
	tick=paralution_time();

	mat.Apply(x,&rhs);
#pragma omp parallel for
	for(i=0;i<N;i++)
	{
		c[i]=alpha*rhs[i]+beta*c[i];

	}



	tack=paralution_time();

	std::cout<<"N="<<N<<", time:"<<(tack-tick)/1e6<<std::endl;


	free(row);
	free(col);
	free(value);
	stop_paralution();

	return 0;
}

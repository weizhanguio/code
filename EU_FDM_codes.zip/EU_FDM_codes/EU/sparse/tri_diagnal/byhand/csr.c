#include<stdio.h>
#include<malloc.h>
#include<omp.h>

int main(int nargs, char** args)
{

	long N=50000000;  //matrix dimension;
	if (nargs>1)
		N = atof(args[1]);

#pragma omp parallel
	{
#pragma omp master
;//		printf("Number of threads = %d\n", omp_get_num_threads());
	}


	double  *val=(double *)malloc((3*N-2)*sizeof(double)); 
	long *col_idx=(long *)malloc((3*N-2)*sizeof(long)); 
	double *row_ptr=(double *)malloc((N+1)*sizeof(double)); 
	double *B=(double *)malloc(N*sizeof(double)); 
	double *c=(double *)malloc(N*sizeof(double)); 
	long i,j;
	double start, finish;
 #pragma omp parallel for
	for(i=0;i<(3*N-2);i++)
		val[i]=-1.0;

 #pragma omp parallel for
 for(i=0;i<N;i++)
                val[3*i]=2.0;

#pragma omp parallel for
	for(i=1;i<=N-2;i++)
	{
		col_idx[3*i-1]=i-1; 
		col_idx[3*i]=i;
		col_idx[3*i+1]=i+1;  
	}
	col_idx[0]=0;
	col_idx[0]=1;
	col_idx[3*N-4]=N-2;
	col_idx[3*N-3]=N-1;


	int s=(3*N-2)+1;

	row_ptr[0]=0;
#pragma omp parallel for
	for(i=1;i<N;i++)
		row_ptr[i]=3*i-1;

	row_ptr[N]=s-1;
#pragma omp parallel for
	for(i=0;i<N;i++)
		B[i]=1.0;

	start = omp_get_wtime();
#pragma omp parallel for default(shared) private(i,j)
	for(i=0;i<N;i++)
	{
		c[i]=0;
		for(j=row_ptr[i];j<=row_ptr[i+1]-1;j++ )
			c[i]=c[i]+val[j]*B[col_idx[j]];

//		printf("%f\n",c[i]);

	}
    
	finish = omp_get_wtime();
  
#pragma omp parallel
        {
#pragma omp master
         printf("%f,N:%ld, threads: %d,time usage=%g\n",c[N-1],N, omp_get_num_threads() ,(finish-start));
        }





	free(val);
	free(col_idx);
	free(row_ptr);
	free(B);
	free(c);
	return 0;

}


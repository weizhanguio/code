#include <stdio.h>
#include <stdlib.h>
#include "mkl.h"
#include<time.h>
int looptimes=10;
int main(int nargs, char** args)
{   

	long  N=1e8;

	if (nargs>1)
		N = atof(args[1]);

	double *A, *B;
	long  m, n, k, i, j;
	double alpha, beta;

	alpha = 1.0; beta = 1.0;
	//	printf (" Allocating memory for matrices aligned on 64-byte boundary for better  performance \n\n");
	A = (double *)mkl_malloc( N*sizeof( double ), 64 );
	B = (double *)mkl_malloc( N*sizeof( double ), 64 );
	if (A == NULL || B == NULL) {
		printf( "\n ERROR: Can't allocate memory for matrices. Aborting... \n\n");
		mkl_free(A);
		mkl_free(B);
		return 1;
	}



#pragma omp parallel for
		for(i=0;i<N;i++)
		{
			A[i]=1.0*(i+i)/N;
			B[i]=1.0*(i*i)/N;
            }
      double start = dsecnd();

        for(j=0;j<looptimes;j++)
        {

		cblas_daxpby(N, alpha, A, 1, beta, B, 1);
	}
	double finish = dsecnd();




#pragma omp parallel
	{
#pragma omp master
		printf("N= %ld, number of threads=%d, average time usage is %e\n",N, omp_get_num_threads( ) , (finish-start)/looptimes );
	}


	mkl_free(A);
	mkl_free(B);

	return 0;
}

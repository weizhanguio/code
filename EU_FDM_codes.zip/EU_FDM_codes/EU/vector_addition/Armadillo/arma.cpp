#include <iostream>
#define ARMA_64BIT_WORD
#include "armadillo"
#include<time.h>
#include<omp.h>

int looptimes=10;

using namespace arma;
using namespace std;

int main(int nargs, char** args)
{

	long N=1e8;
	long i;
	if (nargs>1)
		N = atof(args[1]);


	double  start,finish;
        double alpha=1.0;
        double beta=1.0;
         

	vec A(N);
	vec B(N);
	int j;
#pragma omp parallel for
	for(i=0;i<N;i++)
	{
		A(i)=1.0*(i+i)/N;
		B(i)=1.0*(i*i)/N;
	}

	int counter=0;

	start=omp_get_wtime();
	for(j=0;j<looptimes;j++)
	{


		B=alpha*A+beta*B;
		counter++;

	}
	finish=omp_get_wtime();

	cout<<"B["<<N-1<<"] is: "<<B(N-1)<<endl;

	cout<<counter<<endl;
#pragma omp parallel
	{
#pragma omp master
		printf("N= %ld, number of threads=%d,  average timeusage is %e\n",N, omp_get_num_threads( ) , (finish-start)/looptimes);
	}

	return 0;

}


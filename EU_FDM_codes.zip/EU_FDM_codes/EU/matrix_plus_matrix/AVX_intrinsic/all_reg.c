//p
//compute C=A+B, A,B,C are matrices with size N*N

#include<stdio.h>
#include<time.h>
#include<omp.h>
#include<immintrin.h>
#define   A(x,y)    A[(x)*N+(y)]
#define   B(x,y)    B[(x)*N+(y)]
#define   C(x,y)    C[(x)*N+(y)]
#define   outputbuffer(x,y)    outputbuffer[(x)*N+(y)]

int looptimes=10;


int main( int nargs, char** args )
{
	int i,j,k;
	int N=1e4;
	int block=16;

	if (nargs>1)
		N = atof(args[1]);



	int remains=N%block;
	int index_avx =N-remains-1;  //last index for AVX
	int index_left =N-1;  
	double sum=0.0;
	double *A,*B,*C;
	double start, finish;
	double alpha=1.3;
	double beta=3.1;


	A=(double*)_mm_malloc(N*N*sizeof(double),64);
	B=(double*)_mm_malloc(N*N*sizeof(double),64);
	C=(double*)_mm_malloc(N*N*sizeof(double),64);
	double *outputbuffer;
	outputbuffer=(double*)_mm_malloc(N*N*sizeof(double),64);



	__m256d v_al= _mm256_set1_pd(alpha);
	__m256d v_be= _mm256_set1_pd(beta);


#pragma omp parallel for
	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
		{
			A(i,j)=1.0*(i+j)/N;
			B(i,j)=1.0*(i*j)/N;
		}

	int t;

	start=omp_get_wtime();


	for(t=0;t<looptimes;t++)
	{

#pragma omp parallel default(shared) private(i,j,k)
		{
#pragma omp for          
			for(i=0;i<N;i++)
			{


				__m256d xfsload1;
				__m256d xfsload2;
				__m256d xfsload3;
				__m256d xfsload4;
				__m256d xfsload5;
				__m256d xfsload6;
				__m256d xfsload7;
				__m256d xfsload8;


				__m256d xfsSum1=_mm256_setzero_pd();
				__m256d xfsSum2=_mm256_setzero_pd();
				__m256d xfsSum3=_mm256_setzero_pd();
				__m256d xfsSum4=_mm256_setzero_pd();



				for(j=0;j<=index_avx;j+=16)
				{

					xfsload1=_mm256_load_pd((double*) &A(i,j));   
					xfsload2=_mm256_load_pd((double*) &A(i,j+4));  
					xfsload3=_mm256_load_pd((double*) &A(i,j+8)); 
					xfsload4=_mm256_load_pd((double*) &A(i,j+12));             

					xfsload1=_mm256_mul_pd(xfsload1,v_al);
					xfsload2=_mm256_mul_pd(xfsload2 ,v_al);
					xfsload3=_mm256_mul_pd(xfsload3,v_al);
					xfsload4=_mm256_mul_pd(xfsload4,v_al);


					xfsload5=_mm256_load_pd((double*) &B(i,j));
					xfsload6=_mm256_load_pd((double*) &B(i,j+4));
					xfsload7=_mm256_load_pd((double*) &B(i,j+8));
					xfsload8=_mm256_load_pd((double*) &B(i,j+12));

					xfsload5=_mm256_mul_pd(xfsload5,v_be);
					xfsload6=_mm256_mul_pd(xfsload6 ,v_be);
					xfsload7=_mm256_mul_pd(xfsload7,v_be);
					xfsload8=_mm256_mul_pd(xfsload8,v_be);



					xfsSum1= _mm256_add_pd(xfsload1, xfsload5);
					xfsSum2= _mm256_add_pd(xfsload2, xfsload6);
					xfsSum3= _mm256_add_pd(xfsload3, xfsload7);
					xfsSum4= _mm256_add_pd(xfsload4, xfsload8);

					_mm256_store_pd(&outputbuffer(i,j+0),xfsSum1);
					_mm256_store_pd(&outputbuffer(i,j+4),xfsSum2);
					_mm256_store_pd(&outputbuffer(i,j+8),xfsSum3);
					_mm256_store_pd(&outputbuffer(i,j+12),xfsSum4);

				}
				for(k=0;k<=index_avx;k++) 
					C(i,k)=outputbuffer(i,k);

				for(j=index_avx+1;j<N;j++)
					C(i,j)=alpha*A(i,j)+beta*B(i,j);



			}

		}

	}


	finish=omp_get_wtime();


	printf("C(%ld,%ld):%e\n",N-2,N-2,C(N-2,N-2) );



#pragma omp parallel
	{
#pragma omp master
		printf("N= %d, number of threads=%d,  time usage is %e\n",N, omp_get_num_threads( ) , (finish-start)/looptimes);
	}
	_mm_free(A);
	_mm_free(B);
	_mm_free(C);
	_mm_free(outputbuffer); 

	return 0;

}


#!/bin/bash

#SBATCH --job-name=armadillo
#SBATCH --time=01:05:00
#SBATCH --account=nn2849k
#SBATCH --mem-per-cpu=3850M
###SBATCH --output=Output_File.out
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16

export OMP_NUM_THREADS=14
#numactl --physcpubind=0 ./app 10000
#numactl --physcpubind=0,14 ./app 10000
#numactl --physcpubind=0,2,12,14 ./app 10000
#numactl --physcpubind=0,2,4,6,8,10,12,14 ./app 10000
#numactl --physcpubind=0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15  ./app 10000
#numactl --physcpubind=0,1,2,3,4,5,6,7,8,9  ./app 10000
#numactl --physcpubind=0,1,2,3,4,5,6,7,8,9,10,11  ./app 10000
#numactl --physcpubind=0,1,2,3,4,5,6,7,8,9,10,11,12,13  ./app 10000


#numactl --physcpubind=3,4,5,6,7,8,9,10,11,12  ./app 10000
#numactl --physcpubind=2,3,4,5,6,7,8,9,10,11,12,13  ./app 10000
#numactl --physcpubind=1,2,3,4,5,6,7,8,9,10,11,12,13,14  ./app 10000

./app 10000

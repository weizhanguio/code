#include <stdio.h>
#include <stdlib.h>
#include "mkl.h"
#include<time.h>
#define   A(x,y)    A[(x)*N+(y)]
#define   B(x,y)    B[(x)*N+(y)]
#define   C(x,y)    C[(x)*N+(y)]

int looptimes=5;

int main( int nargs, char** args)
{   

	int  N=1e4;
	if (nargs>1)
		N = atof(args[1]);

	double *A, *B, *C;
	long  m, n, k, i, j;
	double alpha, beta;

	//    m = 10000, k = 10000, n = 10000;
	m = N, k = N, n = N;
	//  m = 50, k = 50, n = 50;
	alpha = 2.1; beta = 1.2;

	A = (double *)mkl_malloc( N*N*sizeof( double ), 64 );
	B = (double *)mkl_malloc( N*N*sizeof( double ), 64 );
	C = (double *)mkl_malloc( N*N*sizeof( double ), 64 );
	if (A == NULL || B == NULL || C == NULL) {
		printf( "\n ERROR: Can't allocate memory for matrices. Aborting... \n\n");
		mkl_free(A);
		mkl_free(B);
		mkl_free(C);
		return 1;
	}

	printf (" Intializing matrix data \n\n");

#pragma omp parallel default(shared) private(i,j)
	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
		{
			A(i,j)=1.0*(i+j)/N;
			B(i,j)=1.0*(i*j)/N;
			C(i,j)=1.0*(j*j)/N;
		}


	double	start = dsecnd();
	for(j=0;j<looptimes;j++)
	{ 
		cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, m, n, k, alpha, A, k, B, n, beta, C, n);
	}
	double 	finish = dsecnd();

#pragma omp parallel
	{
#pragma omp master
		printf("N= %ld, number of threads=%d, average time usage is %e\n",N, omp_get_num_threads( ) , (finish-start)/looptimes );
	}
  
       printf("C(5,5): %e\n",C(5,5));

	printf ("\n Deallocating memory \n\n");
	mkl_free(A);
	mkl_free(B);
	mkl_free(C);

	printf (" Example completed. \n\n");
	return 0;
}

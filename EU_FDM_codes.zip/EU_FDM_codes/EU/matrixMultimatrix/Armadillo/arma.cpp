#include <iostream>
#define ARMA_64BIT_WORD
#include "armadillo"
#include<time.h>
#include<omp.h>
#include<mkl.h>


using namespace arma;
using namespace std;

int looptimes=5;

int main(int nargs, char** args)
{
	// cout << "Armadillo version: " << arma_version::as_string() << endl;

	double  start,finish;
	int N=1e4;
	if (nargs>1)
		N = atof(args[1]);


	double alpha, beta;
	alpha=2.1;
	beta=1.2;

	mat A(N,N);
	mat B(N,N);
	mat C(N,N);


	int i,j;
#pragma omp parallel for default(shared) private(i, j)
	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
		{
			A(i,j)=1.0*(i+j)/N;
			B(i,j)=1.0*(i*j)/N;
			C(i,j)=1.0*(j*j)/N;
		}

//	start=omp_get_wtime();
        start = dsecnd();
	for(i=0;i<looptimes;i++)
	{

	//	C=alpha*A*B+beta*C;
		C=A*B;
	}
       finish = dsecnd();
//	finish=omp_get_wtime();



	cout<<C(5,5)<<endl;

#pragma omp parallel
	{
#pragma omp master
		printf("N= %d, number of threads=%d, average  time usage is %e\n",N, omp_get_num_threads( ) , (finish-start)/looptimes);
	}



	return 0;
}

